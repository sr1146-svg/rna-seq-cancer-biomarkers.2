#!/usr/bin/env bash
set -euo pipefail
# Example: download data (fill in)
# prefetch / fasterq-dump or wget/aria2c commands here
