# Project Notes

- Describe experimental design, cohorts, library prep, barcodes.
- Record decisions (parameters, filters) and rationale.
- Paste links to runs, SRA accessions, etc.
